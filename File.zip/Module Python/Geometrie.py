# -*- coding: utf-8 -*-
"""
Created on Sat Feb  2 20:25:54 2019

Basic Geometrie modul for Calcul mental app.
Help to create WPF Path for geometric figure

V 1.0

@author: vincent sinel
"""

from math import cos,sin,tan,atan2,pi,sqrt

__all__ = ["Geometrie","Clear","Depart","CoutourCouleur","CoutourEpaisseur","CoutourAspect",
           "CoutourAngle","CoutourType","RemplissageCouleur","AjoutLigne",
           "AjoutHorizontal","AjoutVertical","AjoutBezier","AjoutQuadratique",
           "AjoutBezierAdoucie","AjoutQuadratiqueAdoucie","AjoutArc","FermerFigure",
           "Deplacer","GenererPath","AjoutPolygone", "AjoutPoint", "AjoutCercle",
           "AjoutSegment","AjoutCodageSegment","AjoutDroite","AjoutDroiteAngle",
           "AjoutCodageAngle"]

class Geometrie:
    
    # Parametre ne pas toucher
    RESULT = ""
    PARAM_STROKE_COLOR = ""
    PARAM_STROKE_THICKNESS = ""
    PARAM_STROKE_CAPJOIN = ""
    PARAM_STROKE_BORDERJOIN = ""
    PARAM_FILL_COLOR = ""
    PATHSTART = ""
    PATHINFO = ""
    CLOSEINFO = ""
    
    STANDARD_WIDTH = 200
    STANDARD_HEIGHT = 200
    
    LETTER_NEWLAYER = "B"
    LETTER_STROKE_COLOR = "D"
    LETTER_STROKE_THICKNESS = "E"
    LETTER_STROKE_CAPJOIN = "F"
    LETTER_STROKE_BORDERJOIN = "G"
    LETTER_STROKE_BORDERTYPE = "J"
    LETTER_FILL_COLOR = "I"
    LETTER_CANVAS_SIZE = "K"
    
    def __init__(self):
        self.RESULT = ""
        self.Clear()
    
    # Remet a zero tout les paramètres
    def Clear(self):
        self.PARAM_STROKE_COLOR = self.LETTER_STROKE_COLOR+"%s,%s,%s,%s " % (0, 0, 0, 255)
        self.PARAM_STROKE_THICKNESS = self.LETTER_STROKE_THICKNESS+"%s " % (1)
        self.PARAM_STROKE_CAPJOIN = self.LETTER_STROKE_CAPJOIN+"%s " % (2)
        self.PARAM_STROKE_BORDERJOIN = self.LETTER_STROKE_BORDERJOIN+"%s " % (2)
        self.PARAM_STROKE_BORDERTYPE = self.LETTER_STROKE_BORDERTYPE+"%s " % (0)
        self.PARAM_FILL_COLOR = self.LETTER_FILL_COLOR+"%s,%s,%s,%s " % (0, 0, 0, 0)
        self.PATHSTART = ""
        self.PATHINFO = ""
        self.CLOSEINFO = ""
    
    # Ajoute les parametre actuel au résultat
    def AddToResult(self):
        self.RESULT += (self.PARAM_STROKE_COLOR 
        + self.PARAM_STROKE_THICKNESS 
        + self.PARAM_STROKE_CAPJOIN 
        + self.PARAM_STROKE_BORDERJOIN 
        + self.PARAM_STROKE_BORDERTYPE 
        + self.PARAM_FILL_COLOR 
        + self.PATHSTART 
        + self.PATHINFO
		+ self.CLOSEINFO)
                  
	# Genere le texte correspondant à la figure
    def GenererPath(self):
        self.AddToResult()
        self.Clear()
        return self.RESULT
    
    # Initialise le point de depart de la courbe
    def Depart(self,x,y):
        self.PATHSTART = "M "+str(x)+","+str(y)+" "
        
    # Definit la couleur de contour de la figure
    def CoutourCouleur(self,r,g,b,a=255):
        self.PARAM_STROKE_COLOR = self.LETTER_STROKE_COLOR+"%s,%s,%s,%s " % ( r, g, b, a)
    
    # Definit l'epaisseur du contour de la figure
    def CoutourEpaisseur(self,p):
        self.MARGIN = p
        self.PARAM_STROKE_THICKNESS = self.LETTER_STROKE_THICKNESS+"%s " % (p)
        
    # Definit l'aspect des debuts et fin de ligne
    def CoutourAspect(self,p):
        self.PARAM_STROKE_CAPJOIN = self.LETTER_STROKE_CAPJOIN+"%s " % (p)
        
    # Definit l'aspect des angles
    def CoutourAngle(self,p):
        self.PARAM_STROKE_BORDERJOIN = self.LETTER_STROKE_BORDERJOIN+"%s " % (p)
        
    # Definit l'aspect du contour en lui même
    def CoutourType(self,p):
        self.PARAM_STROKE_BORDERTYPE = self.LETTER_STROKE_BORDERTYPE+"%s " % (p)
        
    # Definit la couleur de contour de la figure
    def RemplissageCouleur(self,r,g,b,a=255):
        self.PARAM_FILL_COLOR = self.LETTER_FILL_COLOR+"%s,%s,%s,%s " % (r, g, b, a)
    
    # Ajoute une ligne à la figure
    def AjoutLigne(self,x,y):
        self.PATHINFO += "L"+"%s,%s " % (x,y)
        
    # Ajoute une ligne horizontal à la figure
    def AjoutHorizontal(self,x):
        self.PATHINFO += "H"+"%s " % (x)
       
    # Ajoute une ligne vertical à la figure
    def AjoutVertical(self,y):
        self.PATHINFO += "V"+"%s " % (y)
        
    # Ajoute une courbe de bezier à la figure
    def AjoutBezier(self,c1x,c1y,c2x,c2y,x,y):
        self.PATHINFO += "C"+"%s,%s,%s,%s,%s,%s " % (c1x, c1y, c2x, c2y, x, y)
       
    # Ajoute une courbe quadratique à la figure
    def AjoutQuadratique(self,cx,cy,x,y):
        self.PATHINFO += "Q"+"%s,%s,%s,%s " % (cx, cy, x, y)
        
    # Ajoute une courbe de bezier adoucie à la figure
    def AjoutBezierAdoucie(self,cx,cy,x,y):
        self.PATHINFO += "S"+"%s,%s,%s,%s " % (cx, cy, x, y)
        
    # Ajoute une courbe quadratique adoucie à la figure
    def AjoutQuadratiqueAdoucie(self,cx,cy,x,y):
        self.PATHINFO += "T"+"%s,%s,%s,%s " % (cx, cy, x, y)
        
    # Ajoute un arc elliptique à la figure
    def AjoutArc(self,sx,sy,ang,big,sens,x,y):
        self.PATHINFO += "A"+"%s,%s,%s,%s,%s,%s,%s " % (sx, sy, ang, big, sens, x, y)

    # Ajoute un arc elliptique à la figure
    def NouveauCalque(self):
        self.AddToResult()
        self.RESULT += self.LETTER_NEWLAYER
        self.Clear()
        
    # Definit la fermeture de la figure
    def FermerFigure(self):
        self.CLOSEINFO = "Z "
        
    # Deplace le point de trace
    def Deplacer(self, x , y):
        self.PATHINFO += "M"+"%s,%s " % (x, y)
        
    # Ajoute un polygone à la figure
    def AjoutPolygone(self,listx, listy):
        if (len(listx) < 1 or len(listy) < 1 or len(listx) != len(listy)):
            return
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        self.Depart(listx[0], listy[0])
        for i in range(len(listx) - 1):
            AjoutLigne(listx[1+i], listy[1+i])
        self.FermerFigure()
        self.NouveauCalque()

    # Ajoute un point à la figure
    def AjoutPoint(self,x, y, size):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        self.Depart(x-size/2, y-size/2)
        self.AjoutLigne(x+size/2, y+size/2)
        self.NouveauCalque()
        self.Depart(x-size/2, y+size/2)
        self.AjoutLigne(x+size/2, y-size/2)
        self.NouveauCalque()

    # Ajoute un cercle à la figure OK
    def AjoutCercle(self,x, y, rayon):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        self.Depart(x, y-rayon)
        self.AjoutArc(rayon, rayon ,180, 1,1,x, y+rayon)
        self.AjoutArc(rayon, rayon ,180, 1,1,x, y-rayon)
        self.FermerFigure()
        self.NouveauCalque()

    # Ajoute un segment avec extremité à la figure OK
    def AjoutSegment(self,x1, y1, x2, y2, size = 20):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        self.Depart(x1, y1)
        self.AjoutLigne(x2, y2)
        self.NouveauCalque()
        dx = x2-x1
        dy = y2-y1
        ang = atan2(dy, dx)
        ddx = sin(ang)*size/2
        ddy = cos(ang)*size/2
        Depart(x1-ddx, y1+ddy)
        self.AjoutLigne(x1+ddx, y1-ddy)
        self.NouveauCalque()
        self.Depart(x2+ddx, y2-ddy)
        self.AjoutLigne(x2-ddx, y2+ddy)
        self.NouveauCalque()
      
    # Ajoute une droite à la figure (passant par 2 point)
    def AjoutDroite(self, x1, y1, x2, y2):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        dx = x2-x1
        dy = y2-y1
        if (dx == 0):
            self.Depart(x1, -20)
            self.AjoutVertical(self.STANDARD_HEIGHT + 20)
            self.NouveauCalque()
        else:
            a = dy*1.0 / dx*1.0
            b = y1 - a*x1
            if (abs(a) <= 1):
                y0 = a*(-20) + b
                y3 = a*(self.STANDARD_WIDTH + 20) + b
                self.Depart(-20, y0)
                self.AjoutLigne(self.STANDARD_WIDTH + 20, y3)
                self.NouveauCalque()
            else:
                x0 = (-20-b)/a
                x3 = (self.STANDARD_HEIGHT + 20 - b)/a
                self.Depart(x0,-20)
                self.AjoutLigne(x3, self.STANDARD_HEIGHT + 20)
                self.NouveauCalque()
        
    # Ajoute une droite à la figure (passant par 1 point avec un angle)
    def AjoutDroiteAngle(self, x1, y1, angle):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        if (abs(angle) == pi/2):
            Depart(x1, -20)
            self.AjoutVertical(self.STANDARD_HEIGHT + 20)
            self.NouveauCalque()
        else:
            a = tan(angle)
            b = y1 - a*x1
            if (abs(a) <= 1):
                y0 = a*(-20) + b
                y3 = a*(self.STANDARD_WIDTH + 20) + b
                self.Depart(-20, y0)
                self.AjoutLigne(self.STANDARD_WIDTH + 20, y3)
                self.NouveauCalque()
            else:
                x0 = (-20-b)/a
                x3 = (self.STANDARD_HEIGHT + 20 - b)/a
                self.Depart(x0,-20)
                self.AjoutLigne(x3, self.STANDARD_HEIGHT + 20)
                self.NouveauCalque()
  
    # Ajoute un codage à un segment de la figure figure
    def AjoutCodageSegment(self,x1, y1, x2, y2, typecode = 0, size = 5):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        xc = (x1 + x2) / 2.0
        yc = (y1 + y2) / 2.0
        ang = atan2(y2-y1, x2-x1)
        if (typecode == 0): ## un trait
            xo = xc + size / 2.0 * sin(ang)
            yo = yc - size / 2.0 * cos(ang)
            xe = xc - size / 2.0 * sin(ang)
            ye = yc + size / 2.0 * cos(ang)
            self.Depart(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
        elif(typecode == 1): ## deux trait
            xo = xc + size / 2.0 * (sin(ang) - cos(ang))
            yo = yc - size / 2.0 * (cos(ang) + sin(ang))
            xe = xc - size / 2.0 * (sin(ang) + cos(ang))
            ye = yc + size / 2.0 * (cos(ang) - sin(ang))
            self.Depart(xo,yo)
            self.AjoutLigne(xe,ye)
            xo = xc + size / 2.0 * (sin(ang) + cos(ang))
            yo = yc - size / 2.0 * (cos(ang) - sin(ang))
            xe = xc - size / 2.0 * (sin(ang) - cos(ang))
            ye = yc + size / 2.0 * (cos(ang) + sin(ang))
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
        elif(typecode == 2): ## trois trait
            xo = xc + size / 2.0 * sin(ang)
            yo = yc - size / 2.0 * cos(ang)
            xe = xc - size / 2.0 * sin(ang)
            ye = yc + size / 2.0 * cos(ang)
            self.Depart(xo,yo)
            self.AjoutLigne(xe,ye)
            xo = xc + size / 2.0 * (sin(ang) - cos(ang))
            yo = yc - size / 2.0 * (cos(ang) + sin(ang))
            xe = xc - size / 2.0 * (sin(ang) + cos(ang))
            ye = yc + size / 2.0 * (cos(ang) - sin(ang))
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            xo = xc + size / 2.0 * (sin(ang) + cos(ang))
            yo = yc - size / 2.0 * (cos(ang) - sin(ang))
            xe = xc - size / 2.0 * (sin(ang) - cos(ang))
            ye = yc + size / 2.0 * (cos(ang) + sin(ang))
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
        elif(typecode == 3): ## un cercle
            self.AjoutCercle(xc,yc, size)
        elif(typecode == 4): ## vague
            xo = xc + size / 2.0 * (sin(ang) - cos(ang))
            yo = yc - size / 2.0 * (cos(ang) + sin(ang))
            xc1 = xc - size / 2.0 * (sin(ang) * 2 + cos(ang))
            yc1 = yc + size / 2.0 * (cos(ang) * 2 - sin(ang))
            xc2 = xc + size / 2.0 * (sin(ang) * 2 + cos(ang))
            yc2 = yc - size / 2.0 * (cos(ang) * 2 - sin(ang))
            xe = xc - size / 2.0 * (sin(ang) - cos(ang))
            ye = yc + size / 2.0 * (cos(ang) + sin(ang))
            self.Depart(xo,yo)
            self.AjoutBezier(xc1,yc1,xc2,yc2,xe,ye)
            self.NouveauCalque()
        elif(typecode == 5): ## croix
            xo = xc + size / 2.0 * (sin(ang) - cos(ang))
            yo = yc - size / 2.0 * (cos(ang) + sin(ang))
            xe = xc - size / 2.0 * (sin(ang) - cos(ang))
            ye = yc + size / 2.0 * (cos(ang) + sin(ang))
            self.Depart(xo,yo)
            self.AjoutLigne(xe,ye)
            xo = xc + size / 2.0 * (sin(ang) + cos(ang))
            yo = yc - size / 2.0 * (cos(ang) - sin(ang))
            xe = xc - size / 2.0 * (sin(ang) + cos(ang))
            ye = yc + size / 2.0 * (cos(ang) - sin(ang))
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
            
    # Ajoute un codage d'angle à la figure
    def AjoutCodageAngle(self, x1,y1,xc,yc,x2,y2, typecode = 0, size = 10):
        if (self.PATHINFO != ""):
            self.NouveauCalque()
        ang0 = atan2(y1-yc, x1-xc)
        ang3 = atan2(y2-yc, x2-xc)
        if (typecode == 1): ## deux arc de cercle
            x0 = xc + (size-2) * cos(ang0)
            y0 = yc + (size-2) * sin(ang0)
            x3 = xc + (size-2) * cos(ang3)
            y3 = yc + (size-2) * sin(ang3)
            self.Depart(x0, y0)
            self.AjoutArc(size-2, size-2,ang3-ang0, 0,0,x3, y3)
            self.NouveauCalque()
            x0 = xc + (size+2) * cos(ang0)
            y0 = yc + (size+2) * sin(ang0)
            x3 = xc + (size+2) * cos(ang3)
            y3 = yc + (size+2) * sin(ang3)
            self.Depart(x0,y0)
            self.AjoutArc(size+2, size+2,ang3-ang0, 0,0,x3, y3)
            self.NouveauCalque()
            return

        x0 = xc + size * cos(ang0)
        y0 = yc + size * sin(ang0)
        x3 = xc + size * cos(ang3)
        y3 = yc + size * sin(ang3)
        angc = atan2((y1+y2)/2.0-yc, (x1+x2)/2.0-xc)

        if (typecode == 6): ## un carré
            xc = xc + size * sqrt(2) * cos(angc)
            yc = yc + size * sqrt(2) * sin(angc)
            self.Depart(x0,y0)
            self.AjoutLigne(xc,yc)
            self.AjoutLigne(x3,y3)
            self.NouveauCalque()
            return

        self.Depart(x0, y0)
        self.AjoutArc(size, size,ang3-ang0, 0,0,x3, y3)
        self.NouveauCalque()
        if (typecode == 0): ## Un arc de cercle simple
            self.NouveauCalque()
        if (typecode == 2): ## trois arc de cercle
            x0 = xc + (size-4) * cos(ang0)
            y0 = yc + (size-4) * sin(ang0)
            x3 = xc + (size-4) * cos(ang3)
            y3 = yc + (size-4) * sin(ang3)
            self.Depart(x0, y0)
            self.AjoutArc(size-4, size-4,ang3-ang0, 0,0,x3, y3)
            self.NouveauCalque()
            x0 = xc + (size+4) * cos(ang0)
            y0 = yc + (size+4) * sin(ang0)
            x3 = xc + (size+4) * cos(ang3)
            y3 = yc + (size+4) * sin(ang3)
            self.Depart(x0,y0)
            self.AjoutArc(size+4, size+4,ang3-ang0, 0,0,x3, y3)
            self.NouveauCalque()
            return
        if (typecode == 3): ## un trait
            xo = xc + size / 2.0 * cos(angc)
            yo = yc + size / 2.0 * sin(angc)
            xe = xc + size * 3.0 / 2.0 * cos(angc)
            ye = yc + size * 3.0 / 2.0 * sin(angc)
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
        if (typecode == 4): ## deux trait
            angc = atan2((y1*3+y2*2)/5.0-yc, (x1*3+x2*2)/5.0-xc)
            xo = xc + size / 2.0 * cos(angc)
            yo = yc + size / 2.0 * sin(angc)
            xe = xc + size * 3.0 / 2.0 * cos(angc)
            ye = yc + size * 3.0 / 2.0 * sin(angc)
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            angc = atan2((y1*2+y2*3)/5.0-yc, (x1*2+x2*3)/5.0-xc)
            xo = xc + size / 2.0 * cos(angc)
            yo = yc + size / 2.0 * sin(angc)
            xe = xc + size * 3.0 / 2.0 * cos(angc)
            ye = yc + size * 3.0 / 2.0 * sin(angc)
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()
        if (typecode == 5): ## une croix
            xc = xc + size * cos(angc)
            yc = yc + size * sin(angc)
            xo = xc + size / 2.0 * (sin(angc) - cos(angc))
            yo = yc - size / 2.0 * (cos(angc) + sin(angc))
            xe = xc - size / 2.0 * (sin(angc) - cos(angc))
            ye = yc + size / 2.0 * (cos(angc) + sin(angc))
            self.Depart(xo,yo)
            self.AjoutLigne(xe,ye)
            xo = xc + size / 2.0 * (sin(angc) + cos(angc))
            yo = yc - size / 2.0 * (cos(angc) - sin(angc))
            xe = xc - size / 2.0 * (sin(angc) + cos(angc))
            ye = yc + size / 2.0 * (cos(angc) - sin(angc))
            self.Deplacer(xo,yo)
            self.AjoutLigne(xe,ye)
            self.NouveauCalque()









_inst = Geometrie()
Clear = _inst.Clear
Depart = _inst.Depart
CoutourCouleur = _inst.CoutourCouleur
CoutourEpaisseur = _inst.CoutourEpaisseur
CoutourAspect = _inst.CoutourAspect
CoutourAngle = _inst.CoutourAngle
CoutourType = _inst.CoutourType
RemplissageCouleur = _inst.RemplissageCouleur
AjoutLigne = _inst.AjoutLigne
AjoutHorizontal = _inst.AjoutHorizontal
AjoutVertical = _inst.AjoutVertical
AjoutBezier = _inst.AjoutBezier
AjoutQuadratique = _inst.AjoutQuadratique
AjoutBezierAdoucie = _inst.AjoutBezierAdoucie
AjoutQuadratiqueAdoucie = _inst.AjoutQuadratiqueAdoucie
AjoutArc = _inst.AjoutArc
FermerFigure = _inst.FermerFigure
Deplacer = _inst.Deplacer
GenererPath = _inst.GenererPath
AjoutPolygone = _inst.AjoutPolygone
AjoutPoint = _inst.AjoutPoint
AjoutCercle = _inst.AjoutCercle
AjoutSegment = _inst.AjoutSegment
AjoutCodageSegment = _inst.AjoutCodageSegment
AjoutDroite = _inst.AjoutDroite
AjoutDroiteAngle = _inst.AjoutDroiteAngle
AjoutCodageAngle = _inst.AjoutCodageAngle

AjoutCercle = _inst.AjoutCercle
AjoutCercle = _inst.AjoutCercle

